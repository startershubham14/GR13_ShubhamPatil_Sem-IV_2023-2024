import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class UnitConvGUI extends JFrame {
    private JComboBox<String> conversionTypeComboBox;
    private JTextField inputField;
    private JComboBox<String> sourceUnitComboBox;
    private JComboBox<String> targetUnitComboBox;
    private JLabel resultLabel;

    public UnitConvGUI() {
        setTitle("Unit Converter");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JLayeredPane layeredPane = new JLayeredPane();
        setContentPane(layeredPane);

        ImageIcon backgroundImage = new ImageIcon(System.getProperty("user.home") +"/Desktop/th.jpeg");
        Image scaledImage = backgroundImage.getImage().getScaledInstance(800, 600, Image.SCALE_SMOOTH);
        backgroundImage = new ImageIcon(scaledImage);
        JLabel backgroundImageLabel = new JLabel(backgroundImage);
        backgroundImageLabel.setBounds(0, 0, 800, 600);
        layeredPane.add(backgroundImageLabel, Integer.valueOf(0));
        Font largeFont = new Font("Arial", Font.PLAIN, 20);
        conversionTypeComboBox = new JComboBox<>(
                new String[] { "Length", "Weight", "Temperature", "Number System", "Area" });
        conversionTypeComboBox.setFont(largeFont);
        inputField = new JTextField(10);
        inputField.setFont(largeFont);
        sourceUnitComboBox = new JComboBox<>();     
        sourceUnitComboBox.setFont(largeFont);
        targetUnitComboBox = new JComboBox<>();
        targetUnitComboBox.setFont(largeFont);
        resultLabel = new JLabel();
        resultLabel.setFont(largeFont);

        JButton convertButton = new JButton("Convert");
        convertButton.setFont(largeFont);

        conversionTypeComboBox.setBounds(220, 150, 200, 40);
        inputField.setBounds(220, 200, 200, 40);
        sourceUnitComboBox.setBounds(220, 250, 200, 40);
        targetUnitComboBox.setBounds(220, 300, 200, 40);
        convertButton.setBounds(220, 350, 150, 40);
        resultLabel.setBounds(220, 400, 300, 40);

        layeredPane.add(conversionTypeComboBox, Integer.valueOf(1));
        layeredPane.add(inputField, Integer.valueOf(1));
        layeredPane.add(sourceUnitComboBox, Integer.valueOf(1));
        layeredPane.add(targetUnitComboBox, Integer.valueOf(1));
        layeredPane.add(convertButton, Integer.valueOf(1));
        layeredPane.add(resultLabel, Integer.valueOf(1));

        conversionTypeComboBox.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                populateUnitComboBoxes();
            }
        });

        convertButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                performConversion();
            }
        });

        populateUnitComboBoxes();
    }

    private void populateUnitComboBoxes() {
        String conversionType = (String) conversionTypeComboBox.getSelectedItem();

        if (conversionType == null) {
            return;
        }

        DefaultComboBoxModel<String> unitModel = new DefaultComboBoxModel<>();

        switch (conversionType) {
            case "Length":
                unitModel.addElement("Centimeters");
                unitModel.addElement("Meters");
                unitModel.addElement("Feet");
                unitModel.addElement("Inches");
                unitModel.addElement("Miles");
                unitModel.addElement("Kilometers");
                break;
            case "Weight":
                unitModel.addElement("Kilograms");
                unitModel.addElement("Pounds");
                unitModel.addElement("Ounces");
                break;
            case "Temperature":
                unitModel.addElement("Celsius");
                unitModel.addElement("Fahrenheit");
                break;
            case "Number System":
                unitModel.addElement("Binary");
                unitModel.addElement("Octal");
                unitModel.addElement("Decimal");
                unitModel.addElement("Hexadecimal");
                break;
            case "Area":
                unitModel.addElement("Square Kilometers");
                unitModel.addElement("Hectares");
                unitModel.addElement("Decares");
                unitModel.addElement("Ares");
                unitModel.addElement("Square Meters");
                unitModel.addElement("Square Centimeters");
                unitModel.addElement("Square Millimeters");
                unitModel.addElement("Acres");
                unitModel.addElement("Square Miles");
                unitModel.addElement("Square Yards");
                unitModel.addElement("Square Feet");
                unitModel.addElement("Square Inches");
                break;
        }

        sourceUnitComboBox.setModel(unitModel);

        String[] targetUnitOptions = new String[unitModel.getSize()];
        for (int i = 0; i < unitModel.getSize(); i++) {
            targetUnitOptions[i] = unitModel.getElementAt(i);
        }
        targetUnitComboBox.setModel(new DefaultComboBoxModel<>(targetUnitOptions));
    }

    private void performConversion() {
        String conversionType = (String) conversionTypeComboBox.getSelectedItem();
        String inputValue = inputField.getText().trim();
        String sourceUnit = (String) sourceUnitComboBox.getSelectedItem();
        String targetUnit = (String) targetUnitComboBox.getSelectedItem();

        if (sourceUnit == null || targetUnit == null || sourceUnit.equals(targetUnit)) {
            JOptionPane.showMessageDialog(this, "Please select valid source and target units.");
            return;
        }

        String result;

        switch (conversionType) {
            case "Length":
                result = performLengthConversion(inputValue, sourceUnit, targetUnit);
                break;
            case "Weight":
                result = performWeightConversion(inputValue, sourceUnit, targetUnit);
                break;
            case "Temperature":
                result = performTemperatureConversion(inputValue, sourceUnit, targetUnit);
                break;
            case "Number System":
                result = performNumberSystemConversion(inputValue, sourceUnit, targetUnit);
                break;
            case "Area":
                result = performAreaConversion(inputValue, sourceUnit, targetUnit);
                break;
            default:
                result = "Unsupported conversion.";
                break;
        }

        resultLabel.setText("Result: " + result);
    }

    private String performLengthConversion(String inputValue, String sourceUnit, String targetUnit) {
        double input;
        try {
            input = Double.parseDouble(inputValue);
        } catch (NumberFormatException e) {
            return "Invalid input. Please enter a valid number.";
        }

        double result = 0;

        switch (sourceUnit) {
            case "Centimeters":
                result = performCentimetersConversion(input, targetUnit);
                break;
            case "Meters":
                result = performMetersConversion(input, targetUnit);
                break;
            case "Feet":
                result = performFeetConversion(input, targetUnit);
                break;
            case "Inches":
                result = performInchesConversion(input, targetUnit);
                break;
            case "Miles":
                result = performMilesConversion(input, targetUnit);
                break;
            case "Kilometers":
                result = performKilometersConversion(input, targetUnit);
                break;
            default:
                return "Unsupported conversion.";
        }

        return String.format("%.4f", result);
    }

    private double performCentimetersConversion(double input, String targetUnit) {
        double result = 0;

        switch (targetUnit) {
            case "Meters":
                result = input / 100;
                break;
            case "Feet":
                result = input * 0.0328084;
                break;
            case "Inches":
                result = input * 0.393701;
                break;
            case "Miles":
                result = input / 160934.4;
                break;
            case "Kilometers":
                result = input / 100000;
                break;
            default:
                return 0;
        }

        return result;
    }

    private double performMetersConversion(double input, String targetUnit) {
        double result = 0;

        switch (targetUnit) {
            case "Centimeters":
                result = input * 100;
                break;
            case "Feet":
                result = input * 3.28084;
                break;
            case "Inches":
                result = input * 39.3701;
                break;
            case "Miles":
                result = input / 1609.34;
                break;
            case "Kilometers":
                result = input / 1000;
                break;
            default:
                return 0;
        }

        return result;
    }

    private double performFeetConversion(double input, String targetUnit) {
        double result = 0;

        switch (targetUnit) {
            case "Centimeters":
                result = input * 30.48;
                break;
            case "Meters":
                result = input * 0.3048;
                break;
            case "Inches":
                result = input * 12;
                break;
            case "Miles":
                result = input / 5280;
                break;
            case "Kilometers":
                result = input * 0.0003048;
                break;
            default:
                return 0;
        }

        return result;
    }

    private double performInchesConversion(double input, String targetUnit) {
        double result = 0;

        switch (targetUnit) {
            case "Centimeters":
                result = input * 2.54;
                break;
            case "Meters":
                result = input * 0.0254;
                break;
            case "Feet":
                result = input * 0.0833333;
                break;
            case "Miles":
                result = input / 63360;
                break;
            case "Kilometers":
                result = input * 0.0000254;
                break;
            default:
                return 0;
        }

        return result;
    }

    private double performMilesConversion(double input, String targetUnit) {
        double result = 0;

        switch (targetUnit) {
            case "Centimeters":
                result = input * 160934.4;
                break;
            case "Meters":
                result = input * 1609.34;
                break;
            case "Feet":
                result = input * 5280;
                break;
            case "Inches":
                result = input * 63360;
                break;
            case "Kilometers":
                result = input * 1.60934;
                break;
            default:
                return 0;
        }

        return result;
    }

    private double performKilometersConversion(double input, String targetUnit) {
        double result = 0;

        switch (targetUnit) {
            case "Centimeters":
                result = input * 100000;
                break;
            case "Meters":
                result = input * 1000;
                break;
            case "Feet":
                result = input * 3280.84;
                break;
            case "Inches":
                result = input * 39370.1;
                break;
            case "Miles":
                result = input / 1.60934;
                break;
            default:
                return 0;
        }

        return result;
    }

    private String performWeightConversion(String inputValue, String sourceUnit, String targetUnit) {
        double input;
        try {
            input = Double.parseDouble(inputValue);
        } catch (NumberFormatException e) {
            return "Invalid input. Please enter a valid number.";
        }

        double result = 0;

        switch (sourceUnit) {
            case "Kilograms":
                result = performKilogramsConversion(input, targetUnit);
                break;
            case "Pounds":
                result = performPoundsConversion(input, targetUnit);
                break;
            case "Ounces":
                result = performOuncesConversion(input, targetUnit);
                break;
            default:
                return "Unsupported conversion.";
        }

        return String.format("%.4f", result);
    }

    private double performKilogramsConversion(double input, String targetUnit) {
        double result = 0;

        switch (targetUnit) {
            case "Pounds":
                result = input * 2.20462;
                break;
            case "Ounces":
                result = input * 35.274;
                break;
            default:
                return 0;
        }

        return result;
    }

    private double performPoundsConversion(double input, String targetUnit) {
        double result = 0;

        switch (targetUnit) {
            case "Kilograms":
                result = input / 2.20462;
                break;
            case "Ounces":
                result = input * 16;
                break;
            default:
                return 0;
        }

        return result;
    }

    private double performOuncesConversion(double input, String targetUnit) {
        double result = 0;

        switch (targetUnit) {
            case "Kilograms":
                result = input / 35.274;
                break;
            case "Pounds":
                result = input / 16;
                break;
            default:
                return 0;
        }

        return result;
    }

    private String performTemperatureConversion(String inputValue, String sourceUnit, String targetUnit) {
        double input;
        try {
            input = Double.parseDouble(inputValue);
        } catch (NumberFormatException e) {
            return "Invalid input. Please enter a valid number.";
        }

        double result = 0;

        switch (sourceUnit) {
            case "Celsius":
                result = performCelsiusConversion(input, targetUnit);
                break;
            case "Fahrenheit":
                result = performFahrenheitConversion(input, targetUnit);
                break;
            default:
                return "Unsupported conversion.";
        }

        return String.format("%.4f", result);
    }

    private double performCelsiusConversion(double input, String targetUnit) {
        double result = 0;

        switch (targetUnit) {
            case "Fahrenheit":
                result = (input * 9 / 5) + 32;
                break;
            default:
                return 0;
        }

        return result;
    }

    private double performFahrenheitConversion(double input, String targetUnit) {
        double result = 0;

        switch (targetUnit) {
            case "Celsius":
                result = (input - 32) * 5 / 9;
                break;
            default:
                return 0;
        }

        return result;
    }

    private String performNumberSystemConversion(String inputValue, String sourceUnit, String targetUnit) {

        try {
            switch (sourceUnit) {
                case "Binary":
                    return convertBinary(inputValue, targetUnit);
                case "Octal":
                    return convertOctal(inputValue, targetUnit);
                case "Decimal":
                    return convertDecimal(inputValue, targetUnit);
                case "Hexadecimal":
                    return convertHexadecimal(inputValue, targetUnit);
                default:
                    return "Unsupported source unit.";
            }
        } catch (NumberFormatException e) {
            return "Invalid input. Please enter a valid number for the source unit.";
        }
    }

    private String convertBinary(String inputValue, String targetUnit) {
        int decimalValue = Integer.parseInt(inputValue, 2);

        switch (targetUnit) {
            case "Binary":
                return inputValue;
            case "Octal":
                return Integer.toOctalString(decimalValue);
            case "Decimal":
                return Integer.toString(decimalValue);
            case "Hexadecimal":
                return Integer.toHexString(decimalValue).toUpperCase();
            default:
                return "Unsupported target unit.";
        }
    }

    private String convertOctal(String inputValue, String targetUnit) {
        int decimalValue = Integer.parseInt(inputValue, 8);

        switch (targetUnit) {
            case "Binary":
                return Integer.toBinaryString(decimalValue);
            case "Octal":
                return inputValue;
            case "Decimal":
                return Integer.toString(decimalValue);
            case "Hexadecimal":
                return Integer.toHexString(decimalValue).toUpperCase();
            default:
                return "Unsupported target unit.";
        }
    }

    private String convertDecimal(String inputValue, String targetUnit) {
        int decimalValue = Integer.parseInt(inputValue);

        switch (targetUnit) {
            case "Binary":
                return Integer.toBinaryString(decimalValue);
            case "Octal":
                return Integer.toOctalString(decimalValue);
            case "Decimal":
                return inputValue;
            case "Hexadecimal":
                return Integer.toHexString(decimalValue).toUpperCase();
            default:
                return "Unsupported target unit.";
        }
    }

    private String convertHexadecimal(String inputValue, String targetUnit) {
        int decimalValue = Integer.parseInt(inputValue, 16);

        switch (targetUnit) {
            case "Binary":
                return Integer.toBinaryString(decimalValue);
            case "Octal":
                return Integer.toOctalString(decimalValue);
            case "Decimal":
                return Integer.toString(decimalValue);
            case "Hexadecimal":
                return inputValue.toUpperCase();
            default:
                return "Unsupported target unit.";
        }
    }

    private String performAreaConversion(String inputValue, String sourceUnit, String targetUnit) {
        double input;
        try {
            input = Double.parseDouble(inputValue);
        } catch (NumberFormatException e) {
            return "Invalid input. Please enter a valid number.";
        }

        double result = 0;

        switch (sourceUnit) {
            case "Square Kilometers":
                result = performSquareKilometersConversion(input, targetUnit);
                break;
            case "Hectares":
                result = performHectaresConversion(input, targetUnit);
                break;
            case "Decares":
                result = performDecaresConversion(input, targetUnit);
                break;
            case "Ares":
                result = performAresConversion(input, targetUnit);
                break;
            case "Square Meters":
                result = performSquareMetersConversion(input, targetUnit);
                break;
            case "Square Centimeters":
                result = performSquareCentimetersConversion(input, targetUnit);
                break;
            case "Square Millimeters":
                result = performSquareMillimetersConversion(input, targetUnit);
                break;
            case "Acres":
                result = performAcresConversion(input, targetUnit);
                break;
            case "Square Miles":
                result = performSquareMilesConversion(input, targetUnit);
                break;
            case "Square Yards":
                result = performSquareYardsConversion(input, targetUnit);
                break;
            case "Square Feet":
                result = performSquareFeetConversion(input, targetUnit);
                break;
            case "Square Inches":
                result = performSquareInchesConversion(input, targetUnit);
                break;
            default:
                return "Unsupported conversion.";
        }

        return String.format("%.4f", result);
    }

    private double performSquareKilometersConversion(double input, String targetUnit) {

        return 0;
    }

    private double performHectaresConversion(double input, String targetUnit) {

        return 0;
    }

    private double performDecaresConversion(double input, String targetUnit) {

        return 0;
    }

    private double performAresConversion(double input, String targetUnit) {

        return 0;
    }

    private double performSquareMetersConversion(double input, String targetUnit) {

        return 0;
    }

    private double performSquareCentimetersConversion(double input, String targetUnit) {

        return 0;
    }

    private double performSquareMillimetersConversion(double input, String targetUnit) {

        return 0;
    }

    private double performAcresConversion(double input, String targetUnit) {

        return 0;
    }

    private double performSquareMilesConversion(double input, String targetUnit) {

        return 0;
    }

    private double performSquareYardsConversion(double input, String targetUnit) {

        return 0;
    }

    private double performSquareFeetConversion(double input, String targetUnit) {

        return 0;
    }

    private double performSquareInchesConversion(double input, String targetUnit) {

        return 0;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                UnitConvGUI converter = new UnitConvGUI();
                converter.setVisible(true);
            }
        });
    }
}